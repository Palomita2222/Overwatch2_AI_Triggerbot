import numpy as np
import cv2
import pyautogui
from tensorflow.keras.models import load_model
from time import sleep
import tkinter as tk
from tkinter import font as tkFont

"""
Made py @Palomita2222 on Github
Please star!
The trigger is commented so the window with the bounding boxes are shown.
ONLY USE THIS FOR EDUCATIONAL PURPOSES, YOU WILL GET BANNED
"""

# Load the trained model
model = load_model("Overwatch_bot_detector")

def capture_center_screen():
    # Capture the screen
    screenshot = pyautogui.screenshot()

    # Convert the screenshot to a numpy array
    screenshot_np = np.array(screenshot)

    # Convert RGB to BGR (as OpenCV uses BGR format)
    screenshot_np = cv2.cvtColor(screenshot_np, cv2.COLOR_RGB2BGR)

    # Get the center of the screen
    center_x, center_y = screenshot_np.shape[1] // 2, screenshot_np.shape[0] // 2

    # Crop the center 200x200 pixels
    cropped_img = screenshot_np[center_y-100:center_y+100, center_x-100:center_x+100]

    return cropped_img

def predict_image(img):
    # Preprocess the image
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = np.expand_dims(img, axis=0)

    # Predict using the model
    prediction = model.predict(img)
    return np.argmax(prediction)

root = tk.Tk()
root.title("Overwatch AI Decision")
root.geometry("300x150")
label_font = tkFont.Font(size=20)

# Create a label to display the message
display_label = tk.Label(root, text="WAITING", font=label_font)
display_label.pack(pady=50)

def update_display(prediction):
    if prediction == 1:
        display_label.config(text="SHOOT!", fg="red")
    else:
        display_label.config(text="SAFE", fg="green")

if __name__ == "__main__":
    while True:
        img = capture_center_screen()
        prediction = predict_image(img)
        
        update_display(prediction)  # Update the Tkinter display
        
        if prediction == 1:
            print("True")
            pyautogui.mouseDown()
        else:
            print("False")
            pyautogui.mouseUp()

        root.update_idletasks()  # Update the Tkinter window
        root.update()
        sleep(0.1)