import os
import numpy as np
import cv2
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, MaxPooling2D, Flatten
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.layers import Dropout



# Load images from a folder
def load_images_from_folder(folder, label, img_size=(200,200)):
    images = []
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder, filename))
        if img is not None:
            img = cv2.resize(img, img_size)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            images.append((img, label))
    return images

# Train the model
def train_model(X, y):
    
    datagen = ImageDataGenerator(
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest')
    
    y = to_categorical(y, num_classes=2)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=41)

    model = Sequential()
    model.add(Conv2D(16, (3, 3), activation='relu', input_shape=(200, 200, 3)))
    model.add(MaxPooling2D((2, 2)))
    model.add(Conv2D(16, (3, 3), activation='relu', input_shape=(200, 200, 3)))
    model.add(MaxPooling2D((2, 2)))
    model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(200, 200, 3)))
    model.add(MaxPooling2D((2, 2)))
    model.add(Conv2D(32, (3, 3), activation='relu'))
    model.add(MaxPooling2D((2, 2)))
    model.add(Conv2D(64, (3, 3), activation='relu'))
    model.add(Flatten())
    model.add(Dense(64, activation='relu'))
    model.add(Dropout(0.5))  # Add dropout with 50% probability
    model.add(Dense(2, activation='softmax'))

    model.compile(optimizer='adam', 
                  loss='categorical_crossentropy', 
                  metrics=['accuracy'],
                  run_eagerly=True)
    datagen.fit(X_train)

    # Train the model using data augmentation generator
    model.fit(datagen.flow(X_train, y_train, batch_size=32), epochs=500)

    
    test_loss, test_acc = model.evaluate(X_test, y_test)
    print(f"Test accuracy: {test_acc}")
    
    model.save("Overwatch_bot_detector")
    
    return model

def main():
    X, y = [], []

    # Load "True" images
    true_images = load_images_from_folder("True", 1)
    for img, label in true_images:
        X.append(img)
        y.append(label)

    # Load "False" images
    false_images = load_images_from_folder("False", 0)
    for img, label in false_images:
        X.append(img)
        y.append(label)

    X = np.array(X)
    y = np.array(y)

    # Train the model
    model = train_model(X, y)

if __name__ == "__main__":
    main()
