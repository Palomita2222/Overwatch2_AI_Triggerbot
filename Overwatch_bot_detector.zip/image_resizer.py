import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk, ImageGrab

class ImageResizer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Image Resizer")
        
        # Create a button to paste images
        self.paste_btn = tk.Button(self, text="Paste Image", command=self.paste_image)
        self.paste_btn.pack(pady=20)

        # Radio buttons to select folder
        self.folder_var = tk.StringVar(value="")
        self.true_btn = tk.Radiobutton(self, text="True", variable=self.folder_var, value="True", command=self.save_image)
        self.false_btn = tk.Radiobutton(self, text="False", variable=self.folder_var, value="False", command=self.save_image)
        self.true_btn.pack(side=tk.LEFT, padx=10)
        self.false_btn.pack(side=tk.LEFT, padx=10)
        
        self.image = None
        self.image_counter = 0

    def paste_image(self):
        try:
            # Grab image from clipboard
            self.image = ImageGrab.grabclipboard()
            if isinstance(self.image, Image.Image):
                self.image = self.image.resize((200, 200))
                self.img = ImageTk.PhotoImage(self.image)

                if hasattr(self, "image_label"):
                    self.image_label.destroy()

                self.image_label = tk.Label(self, image=self.img)
                self.image_label.pack(pady=20)

            else:
                raise ValueError("No image data found in clipboard.")
        except Exception as e:
            messagebox.showwarning("Warning", str(e))

    def save_image(self):
        folder = self.folder_var.get()
        if not self.image or not folder:
            messagebox.showwarning("Warning", "Please paste an image and select a folder first!")
            return

        self.image_counter += 1
        save_path = f"./{folder}/{folder}_image_{self.image_counter}.png"
        self.image.save(save_path)

if __name__ == "__main__":
    app = ImageResizer()
    app.mainloop()
